Hepsiburada

Hepsiburada mobil android uygulamasının test scriptlerini içermektedir. Scriptler Java programlama dili kullanılarak oluşturulmuştur.

Projenin oluşturulma aşaması ve tamamlanması sonrasında, testlerin gerçekleştirilmesi için aşağıdaki fiziksel cihaz kullanılmıştır.
Kullanılan Cihazın İşletim Sistemi: Android
Kullanılan Cihazın İşlerim Sistemi Versiyonu: 10
Kullanılan Cihazın Markası ve Modeli: Huawei Mate 20 Lite
Uygulama Versiyonu: Hepsiburada 4.6.0


Testler

Testler için @Test metodu kullanılmıştır. Tests dizinin altına oluşturulan sınıflardan, istinilen senaryo seçilip Run edilebilmektedir.


Kullanılan Data

username = "testautomation174@gmail.com";
password = "Hepsi12345";


İle Yapıldı

IntelliJIDEA
Appium


Yazar

Sedat Servet Yurt - Yazılım Test Mühendisi
