package GeneralScripts;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;

// Her türlü mobil otomasyon projesinde kullanılabilecek atomik fonksiyonlar
public class GeneralScripts {

    // By argümanı olarak iletilen obje ekrana gelene kadar koşumu bekletir
    // Tüm elemanların yüklendiğine emin olmak için her yeni sayfada kullanılması önerilir
    public static void waitFor(WebDriver driver, By by) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }

    // Aranan string ekranda görünene kadar aşağı kaydırır
    public static MobileElement scrollTo(WebDriver driver, String text) {
        return (MobileElement) driver.findElement(MobileBy.
                AndroidUIAutomator("new UiScrollable(new UiSelector()"
                        + ".scrollable(true)).scrollIntoView("
                        + "new UiSelector().text(\"" + text + "\"))"));
    }

    public static MobileElement scrollToID(WebDriver driver, String a) {
        return (MobileElement) driver.findElement(MobileBy.
                AndroidUIAutomator("new UiScrollable(new UiSelector()"
                        + ".scrollable(true)).scrollIntoView("
                        + "new UiSelector().resourceId(\"" + a + "\"))"));
    }

    // Dikey ya da yatay olarak istenilen değerler ve istenilen nokta girilerek sayfa kaydırır
    public static void slide(AndroidDriver driver, int x1, int x2, int y1, int y2) {
        TouchAction action = new TouchAction(driver);
        action.tap(PointOption.point(x1, y1)).perform();
        action.moveTo(PointOption.point(x2, y2)).perform();
        action.release();
        action.perform();
    }

    // Dikey olarak belirtilen noktalardan sayfayı kaydırır
    public static void scroll(AndroidDriver driver) {
        TouchAction action = new TouchAction(driver);
        action.press(PointOption.point(100, 500)).perform();
        action.moveTo(PointOption.point(400, 800)).perform();
        action.release();
        action.perform();
    }

    public static boolean sayfaYenile(AndroidDriver driver, int tekrar) throws InterruptedException {
        boolean return_code;
        int temp = 0;
        for (int i = 0; i < tekrar; i++) {
            Dimension size = driver.manage().window().getSize();
            int anchor = (int) (size.width * 0.50);
            int startPoint = (int) (size.height * 0.90);
            int endPoint = (int) (size.height * 0.10);

            new TouchAction(driver)
                    .press(point(anchor, startPoint))
                    .waitAction(waitOptions(ofMillis(2000)))
                    .moveTo(point(anchor, endPoint))
                    .release().perform();
            Thread.sleep(2000);
            temp = i;
        }
        return temp == tekrar - 1;
    }

    public static void ClickById(AndroidDriver driver, String id) {
        driver.findElement(By.id(id)).click();
    }

    public static void ClickByXpath(AndroidDriver driver, String xpath) {
        driver.findElement(By.xpath(xpath)).click();
    }

    public static boolean checkElementLocation(WebDriver driver, By element, int expectedX, int expectedY) {
        int locatianX;
        int locationY;
        locatianX = driver.findElement(element).getLocation().getX();
        locationY = driver.findElement(element).getLocation().getY();
        return locatianX == expectedX && locationY == expectedY;

    }

    public void waitFor(WebDriver driver, String s) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text='" + s + "']")));
    }

    //Toast message olarak gelen mesajın içeriğini döndürür
    public String getToastMessage(AndroidDriver driver) {
        return driver.findElement(By.xpath("//android.widget.Toast[1]")).getAttribute("text");
    }

    // Popup mesajların içeriğini döndürür
    public String getPopUpMessage(AndroidDriver driver) {
        return driver.findElement(By.id("android:id/message")).getText();
    }

    public void closeLastApp(AndroidDriver driver) {
        waitFor(driver, By.id("com.huawei.android.launcher:id/clear_all_recents_image_button"));
        driver.findElement(By.id("com.huawei.android.launcher:id/clear_all_recents_image_button")).click();
    }

    private By findByTextContains(AndroidDriver driver, String text) {
        return By.xpath("//*[contains(@text,'" + text + "')]");
    }


    public WebElement findElementByTextContains(AndroidDriver driver, String text) {
        return driver.findElement(findByTextContains(driver, text));
    }

    public void waitContainsText(AndroidDriver driver, String text) {
        waitFor(driver, findByTextContains(driver, text));
    }

}

