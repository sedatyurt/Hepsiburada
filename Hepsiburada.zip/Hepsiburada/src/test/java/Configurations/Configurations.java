package Configurations;

import GeneralScripts.GeneralScripts;
import com.jacob.com.LibraryLoader;
import io.appium.java_client.HasSettings;
import io.appium.java_client.Setting;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

public class Configurations extends GeneralScripts {

    protected static AndroidDriver driver;
    //Test için kullanılmak için aşağıdaki kullanıcı datası oluşturulup kullanışmıştır
    protected static String username = "testautomation174@gmail.com";
    protected static String password = "Hepsi12345";

    @BeforeClass
    public void config() throws Exception {

        try{
            DesiredCapabilities caps = new DesiredCapabilities();
            caps.setCapability("deviceName", "HVY0118608000169");
            caps.setCapability("udid", "HVY0118608000169"); //Telefonun ID'si, adb üzerinden "adb list devices" komutuyla öğrenilebilir.
            caps.setCapability("platformName", "Android");
            caps.setCapability("platformVersion", "10"); // Android sürümü
            caps.setCapability("appPackage", "com.pozitron.hepsiburada"); // Uygulamanın adresi
            caps.setCapability("appActivity", "com.hepsiburada.ui.home.BottomNavigationActivity"); // Yüklenecek sayfanın adresi
            caps.setCapability("autoGrantPermissions", "true");
            caps.setCapability("unicodeKeyboard", true);
            caps.setCapability("resetKeyboard", true);
            caps.setCapability("automationName", "uiautomator2");
            caps.setCapability("autoAcceptAlerts", "true");
            caps.setCapability("newCommandTimeout", 60 * 7);
            Runtime.getRuntime().exec("adb shell am start -n io.appium.unlock/.Unlock");
            driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"), caps);

            LibraryLoader.loadJacobLibrary();
            HasSettings settingsDriver = driver;
            settingsDriver.setSetting(Setting.WAIT_FOR_IDLE_TIMEOUT, Duration.of(2, ChronoUnit.SECONDS).toMillis());

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS); //20 saniye hiçbir hareket olmazsa işlem durdurulur

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void quitApp()throws Exception{
        driver.quit();
    }
}
