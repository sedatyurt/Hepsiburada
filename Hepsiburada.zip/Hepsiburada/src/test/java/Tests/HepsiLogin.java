package Tests;

import Configurations.Configurations;
import Pages.HepsiAccountPage;
import Pages.HepsiHomePage;
import Pages.HepsiLoginPage;
import Pages.HepsiUserInfoPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

public class HepsiLogin extends Configurations {
    HepsiHomePage homePage;
    HepsiAccountPage accountPage;
    HepsiLoginPage loginPage;
    HepsiUserInfoPage userInfoPage;

    @Test
    public void Hepsi_Login_Android()
    {
        try{
            driver.navigate().back();
            //Uygulama açılır.
            driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Hepsiburada\"]")).click();

            //Animasyon kapatılır.
            driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"cover_0\"]/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.TextView[2]")).click();

            //Sağ üstteki icona tıklanır.
            homePage = new HepsiHomePage(driver);
            homePage.clickAccountButton();

            //User account sayfası açılır ve Giriş Yapa tıklanır.
            accountPage = new HepsiAccountPage(driver);
            accountPage.clickLoginButton();

            //Login sayfası açılır, login için bilgiler doldurulur ve giriş yapa basılır.
            loginPage = new HepsiLoginPage(driver);
            loginPage.loginMethod(Configurations.username,Configurations.password);

            //Login olduğu kontrol edilir.
            AssertJUnit.assertTrue(driver.findElement(By.xpath("//android.widget.TextView[@text='Hoşgeldiniz']")).isDisplayed());
            driver.findElement(By.id("android:id/button1")).click();

            //User account sayfasının en altında bulunan ad soyad yazılı alana tıklanır.
            accountPage.clickUserField();

            //Uyelik bilgilerim sayfası açılır.
            userInfoPage = new HepsiUserInfoPage(driver);

            //Alanlara yeni isimler girilir.
            //userInfoPage.infoMethod("Test2","Auto2");

            //Güncelle butonuna tıklanır.
            userInfoPage.clickUpdateButton();

            //Başarılı mesajı görülür ve Tamama basılır.
            AssertJUnit.assertTrue(driver.findElement(By.xpath("//android.widget.TextView[@text='Bilgileriniz başarıyla kaydedildi.']")).isDisplayed());
            driver.findElement(By.id("android:id/button1")).click();

            //Çıkış yapıp, tekrar login olunur.
            userInfoPage.clickUserIcon();
            scrollTo(driver, "Çıkış Yap");
            accountPage.clickLogout();
            homePage.clickAccountButton();
            accountPage.clickLoginButton();
            loginPage.loginMethod(Configurations.username,Configurations.password);
            AssertJUnit.assertTrue(driver.findElement(By.xpath("//android.widget.TextView[@text='Hoşgeldiniz']")).isDisplayed());
            driver.findElement(By.id("android:id/button1")).click();

            //Uyelik bilgilerim sayfasına gidilir ve ad soyad kısmının değiştiği kontrol edilir.
            accountPage.clickUserField();
            AssertJUnit.assertTrue(driver.findElement(By.xpath("//android.widget.EditText[@text='Test']")).isDisplayed());
            AssertJUnit.assertTrue(driver.findElement(By.xpath("//android.widget.EditText[@text='Auto']")).isDisplayed());

        }   catch (Exception e){
            e.printStackTrace();
        }
    }
}
