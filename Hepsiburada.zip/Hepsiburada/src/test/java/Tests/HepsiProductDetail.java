package Tests;

import Configurations.Configurations;
import Pages.HepsiAccountPage;
import Pages.HepsiHomePage;
import Pages.HepsiLoginPage;
import Pages.HepsiUserInfoPage;
import io.appium.java_client.TouchAction;
import org.openqa.selenium.By;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

public class HepsiProductDetail extends Configurations {
    HepsiHomePage homePage;
    HepsiAccountPage accountPage;
    HepsiLoginPage loginPage;

    @Test
    public void Hepsi_Product_Detail_Android()
    {
        try
        {
            driver.navigate().back();
            //Uygulama açılır.
            driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Hepsiburada\"]")).click();

            /* Bu işlem login olarak da yapılabilir bunun için aşağıdaki alan yorum satırından çıkarılabilir.
            //Ilk olarak Login olunur.
            homePage = new HepsiHomePage(driver);
            homePage.clickAccountButton();
            accountPage = new HepsiAccountPage(driver);
            accountPage.clickLoginButton();
            loginPage = new HepsiLoginPage(driver);
            loginPage.loginMethod(Configurations.username,Configurations.password);
            AssertJUnit.assertTrue(driver.findElement(By.id("android:id/button1")).isDisplayed());
            driver.findElement(By.id("android:id/button1")).click();
            accountPage.clickCloseButton();
            */


            //Ana sayfada Scroll yapılır ve Super fiyati tekliflerin tümü gösterilir.
            homePage = new HepsiHomePage(driver);
            scrollTo(driver, "Süper Fiyat, Süper Teklif");
            homePage.clickAllSuperOrderButton();

            //Bir ürüne tıklanır.
            driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]/android.view.ViewGroup/android.widget.LinearLayout/android.widget.TextView[1]")).click();

            //driver.findElement(By.id("com.pozitron.hepsiburada:id/productImage")).click();
            //slide(driver,810,90,1070,1070);

            //Sepete ekle butonuna tıklanır ve urun sepete eklenir.
            driver.findElement(By.id("com.pozitron.hepsiburada:id/hb_product_detail_merchant_name")).click();

            //Sepete gidilir.
            driver.navigate().back();
            homePage.clickShoppingCartButton();

            //Urünün sepette olduğu kontrol edilir.
            AssertJUnit.assertTrue(driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.FrameLayout[1]/android.view.ViewGroup/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View/android.view.View[1]/android.view.View[2]/android.widget.ListView/android.view.View/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View[1]/android.view.View/android.widget.TextView")).isDisplayed());

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
