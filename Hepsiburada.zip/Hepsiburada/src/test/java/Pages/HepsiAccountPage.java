package Pages;

import GeneralScripts.GeneralScripts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HepsiAccountPage extends GeneralScripts {
    public By loginButton = By.id("com.pozitron.hepsiburada:id/llUserAccountLogin");
    public By closeButton = By.id("com.pozitron.hepsiburada:id/btnUserAccountClose");

    public By userFieldButton = By.id("com.pozitron.hepsiburada:id/tvUserAccountUsername");
    public By logoutButton = By.xpath("//android.widget.TextView[@text='Çıkış Yap']");

    WebDriver driver;

    public HepsiAccountPage(WebDriver d)
    {
        this.driver = d;
        waitFor(this.driver, loginButton);
    }

    public void clickLoginButton (){
        driver.findElement(loginButton).click();
    }

    public void clickCloseButton(){
        driver.findElement(closeButton).click();
    }

    public void clickUserField(){
        driver.findElement(userFieldButton).click();
    }

    public void clickLogout(){
        driver.findElement(logoutButton).click();
    }
}
