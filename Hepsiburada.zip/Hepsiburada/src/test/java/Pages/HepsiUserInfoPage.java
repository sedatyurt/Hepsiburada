package Pages;

import GeneralScripts.GeneralScripts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HepsiUserInfoPage extends GeneralScripts {
    public By userIcon = By.xpath("//android.widget.ImageView[@content-desc=\"Hesabım\"]");
    public By nameField = By.id("pozitron.hepsiburada:id/etUserFirstName");
    public By lastNameField = By.id("com.pozitron.hepsiburada:id/etUserLastName");
    public By updateButton = By.id("com.pozitron.hepsiburada:id/btnOkSend");

    public By logo = By.id("com.pozitron.hepsiburada:id/tv_toolbar_title");

    WebDriver driver;

    public HepsiUserInfoPage(WebDriver d){
        this.driver = d;
        waitFor(this.driver, logo);
    }

    public void infoMethod(String name, String lastName){
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(lastNameField).sendKeys(lastName);
    }

    public void clickUpdateButton(){
        driver.findElement(updateButton).click();
    }

    public void clickUserIcon(){
        driver.findElement(userIcon).click();
    }
}
