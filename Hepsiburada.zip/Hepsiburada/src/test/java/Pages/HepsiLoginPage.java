package Pages;

import GeneralScripts.GeneralScripts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HepsiLoginPage extends GeneralScripts {
    public By usernameField = By.id("com.pozitron.hepsiburada:id/etLoginEmail");
    public By passwordField = By.id("com.pozitron.hepsiburada:id/etLoginPassword");
    public By loginButton = By.id("com.pozitron.hepsiburada:id/btnLoginLogin");
    public By forgotPasswordButton = By.id("com.pozitron.hepsiburada:id/tvLoginLostPassword");
    public By registerButton = By.id("com.pozitron.hepsiburada:id/tvLoginSignup");

    WebDriver driver;

    public HepsiLoginPage(WebDriver d){
        this.driver = d;
        waitFor(this.driver, usernameField);
    }

    public void loginMethod(String username, String password){
        driver.findElement(usernameField).sendKeys(username);
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(loginButton).click();
    }
}
