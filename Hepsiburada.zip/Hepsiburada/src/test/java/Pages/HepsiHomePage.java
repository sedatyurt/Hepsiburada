package Pages;

import GeneralScripts.GeneralScripts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HepsiHomePage extends GeneralScripts {

    public By exploreButton = By.xpath("//android.widget.FrameLayout[@content-desc=\"Keşfet\"]");
    public By categoryButton = By.xpath("//android.widget.FrameLayout[@content-desc=\"Kategoriler\"]");
    public By shoppingCartButton = By.xpath("//android.widget.FrameLayout[@content-desc=\"Sepet\"]");
    public By orderButton = By.xpath("//android.widget.FrameLayout[@content-desc=\"Siparişlerim\"]");
    public By accountButton = By.id("com.pozitron.hepsiburada:id/account_icon_frame");
    public By logo = By.id("com.pozitron.hepsiburada:id/image_message_of_day");
    public By accountIcon = By.id("com.pozitron.hepsiburada:id/account_icon");
    public By allSuperOrder = By.id("com.pozitron.hepsiburada:id/dod_all");

    WebDriver driver;

    public HepsiHomePage(WebDriver d)
    {
        this.driver = d;
        waitFor(this.driver, logo);
    }

    public void clickAccountButton()
    {
        driver.findElement(accountButton).click();
    }

    public void clickAccountIcon()
    {
        driver.findElement(accountIcon).click();
    }

    public void clickAllSuperOrderButton()
    {
        driver.findElement(allSuperOrder).click();
    }

    public void clickShoppingCartButton()
    {
        driver.findElement(shoppingCartButton).click();
    }

    public void clickExploreButton()
    {
        driver.findElement(exploreButton).click();
    }

}



// animasyon kapatma xPathi
/*
//android.view.ViewGroup[@content-desc="cover_0"]/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.TextView[2]
 */